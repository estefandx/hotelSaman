<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>formato de correo </title>
</head>
<body>
    <p><strong>Nombre: </strong><?php echo e($nombre); ?>   </p>
    <p><strong>Solicitud: </strong> <?php echo e($seccion); ?>  </p>
    <p><strong>Correo: </strong> <?php echo e($mail); ?>  </p>
    <p><strong>Telefono: </strong><?php echo e($numero); ?>   </p>
    <p><strong>Mensaje: </strong> <?php echo e($mensaje); ?>  </p>
</body>
</html>