<?php $__env->startSection('contenido'); ?>
    <style>
        .header {
            color: #36A0FF;
            font-size: 27px;
            padding: 10px;
        }

        .bigicon {
            font-size: 35px;
            color: #36A0FF;
        }
    </style>

    <div class="container">
        <div class="row">
        <div class="col-lg-10">
        <table id="example" class="table table-bordered">
            <thead>
            <tr>
                <th>id</th>
                <th>imagen</th>
                <th>seccion</th>
                <th>Acción</th>


            </tr>
            </thead>
            <tbody>
             <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($photo->id); ?></td>
                    <td>
                        <img src="fotos/<?php echo e($photo->nombre); ?>" alt="foto de "<?php echo e($photo->seccion); ?> width="100" height="100">
                    </td>
                    <td><?php echo e($photo->seccion); ?></td>
                    <td>
                        <form  role="form"  method="post" action="<?php echo e(url("/foto/{$photo->id}")); ?>">
                            <?php echo e(method_field('delete')); ?>

                            <?php echo e(csrf_field()); ?>


                            <input class="btn btn-danger" type="submit" value="eliminar" />
                        </form>
                    </td>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </tbody>

        </table>
            <center><?php echo $photos->render(); ?></center>
        </div>
    </div>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panelmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>