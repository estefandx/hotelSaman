<!DOCTYPE html>
<html lang="eng">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<?php 
		$id = $_POST['id'];
	    $nombre = $_POST['nombre'];
	    $mail = $_POST['mail']; 
	    $numero = $_POST['numero'];
	    $mensaje = $_POST['mensaje'];
 ?>

	<?php echo $nombre?>
	<?php echo $mail?>
	<?php echo $numero?>
	<?php echo $mensaje?>
</body>
</html>

